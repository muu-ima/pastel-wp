<?php

namespace Google\Site_Kit_Dependencies\GuzzleHttp\Exception;

/**
 * Exception when a client error is encountered (4xx codes)
 */
class ClientException extends \Google\Site_Kit_Dependencies\GuzzleHttp\Exception\BadResponseException
{
}
