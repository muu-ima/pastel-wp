<?php

namespace Google\Site_Kit_Dependencies\GuzzleHttp\Exception;

/**
 * Exception when a server error is encountered (5xx codes)
 */
class ServerException extends \Google\Site_Kit_Dependencies\GuzzleHttp\Exception\BadResponseException
{
}
