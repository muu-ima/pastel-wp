<?php

namespace Google\Site_Kit_Dependencies\GuzzleHttp\Exception;

use Google\Site_Kit_Dependencies\Psr\Http\Client\ClientExceptionInterface;
interface GuzzleException extends \Google\Site_Kit_Dependencies\Psr\Http\Client\ClientExceptionInterface
{
}
