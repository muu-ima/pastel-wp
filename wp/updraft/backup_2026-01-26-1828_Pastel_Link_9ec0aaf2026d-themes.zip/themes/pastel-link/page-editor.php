<?php
/**
 * Template Name: Editor (Fullscreen)
 */
if (!defined('ABSPATH')) exit;

// このページだけWPの上の黒バー（管理バー）を消したい場合は true
$hide_admin_bar = true;
if ($hide_admin_bar) {
  add_filter('show_admin_bar', '__return_false');
}
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php wp_head(); ?>

  <style>
    /* 余白ゼロの全画面 */
    html, body { height: 100%; margin: 0; }
    body { background: #000; }
    .pl-editor-wrap { height: 100vh; }
    .pl-editor-iframe {
      width: 100%;
      height: 100%;
      border: 0;
      display: block;
      background: #000;
    }
  </style>
</head>

<body <?php body_class(); ?>>
  <div class="pl-editor-wrap">
    <iframe
      class="pl-editor-iframe"
      src="https://muu-braille-card.vercel.app/editor?embed=1"
      allow="clipboard-read; clipboard-write; fullscreen"
      loading="lazy"
    ></iframe>
  </div>

  <?php wp_footer(); ?>
</body>
</html>
