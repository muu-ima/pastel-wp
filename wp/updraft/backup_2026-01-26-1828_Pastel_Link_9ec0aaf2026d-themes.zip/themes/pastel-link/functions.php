<?php
/**
 * Pastel Link theme functions
 */
if (!defined('ABSPATH')) {
  exit;
}

/**
 * Theme setup
 */
add_action('after_setup_theme', 'pastel_link_setup');
function pastel_link_setup() {
  // <title> をWPに任せる
  add_theme_support('title-tag');

  // アイキャッチ
  add_theme_support('post-thumbnails');

  // Newsカード用（横長カードに合わせる）
  add_image_size('pl-news-thumb', 960, 640, true);

  // ブロックのワイド幅（必要なら）
  add_theme_support('align-wide');

  // HTML5マークアップ
  add_theme_support('html5', array(
    'search-form',
    'comment-form',
    'comment-list',
    'gallery',
    'caption',
    'style',
    'script',
  ));

  // メニュー
  register_nav_menus(array(
    'primary' => 'Primary Menu',
    'footer'  => 'Footer Menu',
  ));
}

/**
 * Enqueue CSS
 */
add_action('wp_enqueue_scripts', 'pastel_link_enqueue_assets');
function pastel_link_enqueue_assets() {
  $css_path = get_stylesheet_directory() . '/style.css';
  $ver = file_exists($css_path) ? filemtime($css_path) : null;

  wp_enqueue_style(
    'pastel-link-style',
    get_stylesheet_uri(),
    array(),
    $ver
  );
}

/**
 * News（お知らせ）: CPT
 */
add_action('init', 'pastel_link_register_news');
function pastel_link_register_news() {
  register_post_type('pl_news', array(
    'label' => 'News',
    'public' => true,
    'has_archive' => true,
    'menu_icon' => 'dashicons-megaphone',
    'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
    'rewrite' => array('slug' => 'news'),
    'show_in_rest' => true,
  ));

  register_taxonomy('pl_news_cat', array('pl_news'), array(
    'label' => 'News Category',
    'public' => true,
    'hierarchical' => true,
    'rewrite' => array('slug' => 'news-category'),
    'show_in_rest' => true,
  ));
}
